Oslo Messaging Library
======================

The Oslo messaging API supports RPC and notifications over a number of
different messaging transports.

See also: `Library Documentation <http://docs.openstack.org/developer/oslo.messaging>`_
